<!DOCTYPE html>
<head>  
    <meta charset = "utf-8">
        <title>View Order</title>
</head> 
<body> 
<?php

// if ($_SERVER['REQUEST_METHOD'] == POST) form has been submitted by POST method


?>
</body>
</html>
