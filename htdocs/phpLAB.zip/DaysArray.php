<html>
  <head>
    <title>Days of the Week</title>
  </head>
  <body>
    <?php

    $Days = Array ("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    echo "The days of the week in English are: <br />
    $Days[0] <br />
                                              $Days[1] <br />
                                              $Days[2] <br />
                                              $Days[3] <br />
                                              $Days[4] <br />
                                              $Days[5] <br />
                                              $Days[6]<br /><br />";


     $Days[0] = "Dimanche";
     $Days[0] = "Lundi";
     $Days[0] = "Mardi";
     $Days[0] = "Mercredi";
     $Days[0] = "Jeudi";
     $Days[0] = "Vendredi";
     $Days[0] = "Samedi";

     echo "The days of the week in French are: <br />
     $Days[0] <br />
                                               $Days[1] <br />
                                               $Days[2] <br />
                                               $Days[3] <br />
                                               $Days[4] <br />
                                               $Days[5] <br />
                                               $Days[6]";

      ?>
</html>
