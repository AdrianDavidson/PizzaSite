<!DOCTYPE html >
<html>
<head>
<title>Today&rsquo;s Date</title>
<meta charset=”utf-8">
</head>
<body>
<p>Today&rsquo;s date (according to this web server) is
<?php
echo date('l, F dS Y.');
?>
</p>
</body>
</html>
